#include "geometrygenerator.hpp"

GeometryGenerator::GeometryGenerator(){
}
